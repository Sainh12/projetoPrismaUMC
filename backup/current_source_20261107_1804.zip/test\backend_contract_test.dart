import 'package:projeto_base_prisma/domain/Aluno.dart';
import 'package:projeto_base_prisma/domain/Professor.dart';
import 'package:test/test.dart';

void main() {
  group('Aluno', () {
    final json = <String, dynamic>{
      'nome': 'Aluno Teste',
      'email': 'aluno@example.test',
      'cpf': '12345678901',
      'escola': 'Escola Teste',
      'tipo_usuario': 'aluno',
      'serie': '3 ano',
    };

    test('fromJson usa o ID recebido e converte os campos do aluno', () {
      final aluno = Aluno.fromJson('aluno-id-1', json);

      expect(aluno.id, 'aluno-id-1');
      expect(aluno.nome, 'Aluno Teste');
      expect(aluno.email, 'aluno@example.test');
      expect(aluno.cpf, '12345678901');
      expect(aluno.escola, 'Escola Teste');
      expect(aluno.tipoUsuario, 'aluno');
      expect(aluno.serie, '3 ano');
    });

    test('fromJson gera um ID quando recebe null', () {
      final aluno = Aluno.fromJson(null, json);

      expect(aluno.id, isNotEmpty);
    });

    test('toMap produz as duas tabelas usadas pelo cadastro', () {
      final aluno = Aluno.fromJson('aluno-id-1', json);
      final map = aluno.toMap();

      expect(map['Usuarios'], {
        'usuario_id': 'aluno-id-1',
        'nome_completo': 'Aluno Teste',
        'cpf': '12345678901',
        'email': 'aluno@example.test',
        'senha': null,
        'escola': 'Escola Teste',
        'tipo_usuario': 'aluno',
      });
      expect(map['Aluno'], {'id': 'aluno-id-1', 'serie': '3 ano'});
    });

    test('fromMap mapeia uma linha retornada pelo banco', () {
      final aluno = Aluno.fromMap({
        'usuario_id': 'aluno-id-2',
        'nome_completo': 'Outro Aluno',
        'cpf': '12345678902',
        'email': 'outro@example.test',
        'escola': 'Escola B',
        'tipo_usuario': 'aluno',
        'serie': '2 ano',
      });

      expect(aluno.id, 'aluno-id-2');
      expect(aluno.nome, 'Outro Aluno');
      expect(aluno.serie, '2 ano');
      expect(aluno.senha, isNull);
    });
  });

  group('Professor', () {
    final json = <String, dynamic>{
      'nome': 'Professor Teste',
      'email': 'professor@example.test',
      'cpf': '10987654321',
      'escola': 'Escola Teste',
      'tipo_usuario': 'professor',
      'materia': 'Matemática',
      'licenciatura': 'Matemática',
    };

    test('fromJson usa o ID recebido e converte os campos do professor', () {
      final professor = Professor.fromJson('professor-id-1', json);

      expect(professor.id, 'professor-id-1');
      expect(professor.nome, 'Professor Teste');
      expect(professor.email, 'professor@example.test');
      expect(professor.cpf, '10987654321');
      expect(professor.escola, 'Escola Teste');
      expect(professor.tipoUsuario, 'professor');
      expect(professor.materia, 'Matemática');
      expect(professor.licenciatura, 'Matemática');
    });

    test('toMap produz as duas tabelas usadas pelo cadastro', () {
      final professor = Professor.fromJson('professor-id-1', json);
      final map = professor.toMap();

      expect(map['Usuarios'], {
        'usuario_id': 'professor-id-1',
        'nome_completo': 'Professor Teste',
        'cpf': '10987654321',
        'email': 'professor@example.test',
        'senha': null,
        'escola': 'Escola Teste',
        'tipo_usuario': 'professor',
      });
      expect(map['Professores'], {
        'id': 'professor-id-1',
        'licenciatura': 'Matemática',
        'materia': 'Matemática',
      });
    });
  });
}
