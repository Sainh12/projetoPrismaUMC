# Reanálise focada: API, senhas e persistência

## Escopo

Analisei a versão atual de `LoginAPI`, do upload de arquivos, dos modelos, do gerenciador SQLite, do entrypoint e dos testes. Nesta revisão, alterei apenas arquivos de teste/relatório e fiz as renomeações de padronização descritas na última seção.

Os testes que dependem do SQLite ou da API completa não foram declarados aprovados: os handlers instanciam `GerenciadorBancoDeDados` diretamente, e o servidor não expõe uma factory pública de handler nem uma forma de configurar porta/encerramento para integração isolada.

## Estado geral

**O fluxo de cadastro e login ainda não está funcional/seguro.** Há dois bloqueios principais no cadastro: o objeto `User` continua nulo por sombreamento da variável no `switch`, e o modelo envia `senha: null` para uma coluna `NOT NULL`. O código chamado de hash é `hash` da biblioteca `path`, não hash criptográfico de senha; o resultado não é usado no cadastro nem no login.

Já estão presentes: inicialização da API de usuário pelo `bin`, lookup por e-mail na query string, retorno de DTO sem senha, IDs passados na URL de update/delete, tentativa de validação de JSON em parte das rotas e limite de 100 MiB por arquivo no upload.

## Tabela dos problemas que ainda precisam de correção

| # | Prioridade | Onde | Erro reproduzível / consequência |
|---|---|---|---|
| 1 | **Bloqueante** | `lib/infraestructure/controller/http/login_api.dart`, import e chamadas `passwordHasher.hash(...)` | `passwordHasher` é alias de `package:path/path.dart`. `hash(String)` dessa biblioteca calcula um inteiro de hash de caminho; não é uma função criptográfica de senha. O analyzer também avisa que `await` está sendo usado sobre um `int`. O valor não entra no cadastro nem na verificação de login. |
| 2 | **Bloqueante** | `_postLogin`, variável `User? user` e `switch` | Cada `case` declara `final user`, criando uma variável local que esconde a variável externa. A variável externa continua `null`; `user!` lança erro em toda tentativa de cadastro com tipo válido. |
| 3 | **Bloqueante** | `Aluno.fromJson`, `Professor.fromJson`, `toMap`, `insertUser`, esquema `Usuarios.senha` | Os factories não recebem nem atribuem senha/hash. `toMap()` envia `senha: null`, mas a tabela exige `senha NOT NULL`; depois de corrigido o `user!`, o INSERT ainda falhará por restrição. |
| 4 | **Bloqueante** | `_postLogin` e `_enterSystem` | Os handlers passam `Map` como `Response.body` em várias respostas. Shelf aceita `String`, bytes, stream ou `null`; um `Map` não serializado pode lançar `ArgumentError` ao construir/enviar a resposta. Use `jsonEncode`. |
| 5 | **Bloqueante** | `getUserByEmailAndPassword` no gerenciador e `_enterSystem` | A consulta faz `WHERE email = ? AND senha = ?`, comparando texto literal. Com BCrypt, cada hash tem salt e não é determinístico; não se pode gerar um hash novo e compará-lo com `=`. É necessário buscar o hash salvo por e-mail e executar `checkpw` sobre ele. |
| 6 | **Bloqueante** | `atualizacaoUsuario` no gerenciador | A primeira consulta usa `WHERE id = ?` na tabela `Usuarios`, cuja chave é `usuario_id`; portanto não localiza o usuário. Depois, atualiza todas as tabelas com `WHERE usuario_id = ?`, mas `Aluno` e `Professores` possuem coluna `id`, não `usuario_id`. Atualização falha para os dois tipos. |
| 7 | **Alto** | `_postLogin` | Entrada de `tipo_usuario` inválida retorna 400 corretamente, mas campos como senha/email/CPF não são validados como strings não vazias. Qualquer `DatabaseException` é convertido em 409, mesmo se for falha de disco/esquema, e o erro/stack não são registrados. |
| 8 | **Alto** | `_getId` | Para e-mail ausente, o corpo literal `{message} : email nulo` não é JSON válido e não tem `Content-Type` JSON. O cliente não consegue decodificá-lo de maneira consistente. |
| 9 | **Alto** | `_getUser`, `_getId`, inicialização em `bin/projeto_base_prisma.dart` | O servidor escuta em `anyIPv4` e consulta/ID não exigem autenticação. `/info` retorna nome, e-mail, CPF e escola a quem souber um e-mail. Isso expõe dados pessoais a qualquer cliente que alcance a API. |
| 10 | **Alto** | `file_controller_api.dart` e inicialização atual | O endpoint de upload existe em uma classe própria na porta 8081, mas o entrypoint atual só chama `LoginApi.iniciando()`. Não encontrei inicialização de `FileController`; portanto `/api/upload` e `/api/video/...` não ficam disponíveis ao executar o entrypoint atual. Se forem iniciados sem autenticação, upload e DELETE ficam abertos a qualquer cliente alcançável. |
| 11 | **Médio** | `_getVideo` em `file_controller_api.dart` | O parser usa `firstMatch`, podendo aceitar apenas o prefixo de um header com múltiplos ranges/lixo adicional. `Range` precisa ser validado integralmente; testar suffix range, arquivo vazio e limites fora do tamanho. |
| 12 | **Médio** | `DatabaseHelperUsers` | O esquema segue na versão 1 sem `onUpgrade`. A primeira mudança de esquema depois da instalação não será aplicada a bancos já existentes. |
| 13 | **Médio** | `test/backend_contract_test.dart` | A suíte antiga não acompanhava a assinatura atual `fromJson(id, json)` e chamava `startApi`, que foi tornado privado. A suíte foi reescrita para os modelos atuais; integração HTTP/SQLite continua descoberta como lacuna, não como teste passando. |
| 14 | **Médio** | Arquitetura de persistência | O repositório usa SQLite (`sqflite`). O `compose.yml` está todo comentado, logo não inicia MySQL nem configura backend. Escolher e documentar se SQLite é local do app ou se haverá backend central com banco servidor antes de tratar isso como produção multiusuário. |
| 15 | **Médio** | `LoginApi.iniciando()` | Inicia o socket mas retorna só endereço/porta; descarta a referência `HttpServer`. O app não consegue encerrar o listener de forma controlada, e uma segunda chamada pode tentar registrar novamente as mesmas rotas. |

## Como implementar hash de senha de ponta a ponta

### O que está errado no hash atual

No arquivo da API há:

```dart
import 'package:path/path.dart' as passwordHasher;
final hash = await passwordHasher.hash(senha);
```

`package:path` serve para manipular caminhos de arquivo. O método `hash` do contexto de caminhos retorna um `int` para hash de caminho; não protege segredo, não usa salt criptográfico e não é reversível/validável como hash de senha. `await` não transforma um valor síncrono em operação segura. Além disso:

- no cadastro, `hash` é calculado mas nunca passado ao modelo ou ao repositório;
- `Aluno.fromJson`/`Professor.fromJson` ignoram `senha`;
- o repositório faz comparação SQL direta da senha;
- uma tabela pode continuar recebendo `NULL` na coluna obrigatória;
- o `final user` dentro de cada `case` não preenche o `User? user` externo.

### Passo 1 — Adicionar uma biblioteca de hash própria para senha

Um exemplo simples usando BCrypt é o pacote [`bcrypt`](https://pub.dev/packages/bcrypt), que fornece `BCrypt.hashpw` e `BCrypt.checkpw`. Não use `String.hashCode`, `package:path` ou SHA-256 puro para guardar senhas. SHA-256 é rápido demais para resistir a tentativa offline em caso de vazamento.

Adicionar em `pubspec.yaml`:

```yaml
dependencies:
  bcrypt: ^1.2.0
```

Depois executar `flutter pub get` (ou `dart pub get` no pacote Dart correspondente). Não alterei o manifesto nem instalei o pacote nesta análise.

### Passo 2 — Criar um serviço pequeno que centralize hash e verificação

Criar `lib/infraestructure/security/password_hasher.dart`:

```dart
import 'dart:isolate';

import 'package:bcrypt/bcrypt.dart';

class PasswordHasher {
  static Future<String> hashPassword(String password) {
    return Isolate.run(
      () => BCrypt.hashpw(password, BCrypt.gensalt()),
    );
  }

  static Future<bool> verifyPassword({
    required String password,
    required String storedHash,
  }) {
    return Isolate.run(
      () => BCrypt.checkpw(password, storedHash),
    );
  }
}
```

`gensalt()` cria um salt novo; `hashpw` grava no próprio resultado o salt e os parâmetros BCrypt. Por isso, duas chamadas para a mesma senha normalmente geram strings diferentes. `checkpw(senhaDigitada, hashSalvo)` extrai as informações do hash salvo e verifica a senha. `Isolate.run` evita fazer o trabalho custoso de hash no isolate principal de UI/servidor; a compatibilidade/desempenho deve ser testada nas plataformas-alvo.

O custo (`work factor`) precisa ser escolhido por benchmark no hardware real e revisto periodicamente. Não reduza o custo para acelerar testes. BCrypt tem limite de entrada em bytes; valide o tamanho da senha conforme a biblioteca e a política escolhida. Para um sistema novo, considere Argon2id se houver biblioteca mantida e compatível com todas as plataformas do projeto.

### Passo 3 — Validar a senha recebida e calcular o hash só no cadastro

No handler, primeiro validar o tipo e o valor:

```dart
final senha = _requiredString(data, 'senha');
if (senha == null) {
  return _json(400, {'message': 'senha obrigatória'});
}

final senhaHash = await PasswordHasher.hashPassword(senha);
```

Não devolver `senha` nem `senhaHash` na resposta, não imprimir nenhum deles e não salvar a senha original em log. O raw password deve existir apenas durante a requisição e a verificação.

Construir o usuário **uma única vez**, atribuindo a variável externa em vez de declarar uma variável local:

```dart
User user;
switch (tipo) {
  case 'professor':
    user = Professor.fromJson(null, data);
    break;
  case 'aluno':
    user = Aluno.fromJson(null, data);
    break;
  default:
    return _json(400, {'message': 'tipo_usuario inválido'});
}

final inserted = await gerenciador.insertUser(
  user,
  passwordHash: senhaHash,
);
```

O exemplo pressupõe a alteração da assinatura do repositório mostrada no passo seguinte. Os factories atuais não leem a senha do JSON; mantenha essa propriedade e passe o hash separadamente, para evitar que o modelo receba/serializa a senha em texto puro.

### Passo 4 — Persistir somente o hash dentro da transação

Alterar `insertUser` para receber `passwordHash` e colocá-lo na linha de `Usuarios` antes do INSERT. As linhas de perfil (`Aluno`/`Professores`) continuam na mesma transação:

```dart
Future<int> insertUser(
  User user, {
  required String passwordHash,
}) async {
  final db = await DatabaseHelperUsers.instance.database;

  return db.transaction((txn) async {
    final existing = await txn.query(
      'Usuarios',
      columns: ['usuario_id'],
      where: 'email = ? OR cpf = ?',
      whereArgs: [user.email, user.cpf],
      limit: 1,
    );
    if (existing.isNotEmpty) return 0;

    final tables = user.toMap();
    final userRow = Map<String, Object?>.from(tables['Usuarios']!)
      ..['senha'] = passwordHash;

    await txn.insert('Usuarios', userRow);
    for (final entry in tables.entries) {
      if (entry.key == 'Usuarios') continue;
      await txn.insert(entry.key, entry.value);
    }
    return 1;
  });
}
```

O esquema atual declara `senha VARCHAR(255) NOT NULL`, tamanho suficiente para hash BCrypt. Para deixar o esquema semanticamente claro, numa migração futura renomeie para `senha_hash`; não renomeie coluna sem aumentar a versão e escrever `onUpgrade`. A implementação acima usa o nome de coluna que já existe, evitando exigir migração para começar a guardar o hash.

### Passo 5 — Verificar o hash no login, sem comparar hashes por SQL

O repositório deve buscar o hash salvo apenas pelo e-mail e verificar a senha em Dart:

```dart
Future<bool> verifyUserPassword(String email, String password) async {
  final db = await DatabaseHelperUsers.instance.database;
  final rows = await db.query(
    'Usuarios',
    columns: ['senha'],
    where: 'email = ?',
    whereArgs: [email],
    limit: 1,
  );
  if (rows.isEmpty) return false;

  final storedHash = rows.single['senha'];
  if (storedHash is! String || storedHash.isEmpty) {
    throw StateError('Hash de senha inválido no registro.');
  }

  return PasswordHasher.verifyPassword(
    password: password,
    storedHash: storedHash,
  );
}
```

No handler, validar JSON/campos, chamar `verifyUserPassword(email, senha)` e responder `401` com mensagem genérica quando retornar `false`. Não criar um hash novo no login para comparar com o hash existente: o salt torna a igualdade direta incorreta.

Depois do login válido, o backend ainda precisa criar uma sessão/token assinado e validar esse token nas rotas protegidas. Hash de senha protege credencial armazenada; não autentica automaticamente as próximas requisições. Envie credenciais somente por HTTPS quando a API atravessar uma rede não confiável.

### Passo 6 — Tratar senhas já existentes

Registros antigos em texto puro não podem ser convertidos para BCrypt sem conhecer a senha original. Em desenvolvimento, pode-se recriar o banco de teste. Em produção, planeje redefinição obrigatória de senha ou migração temporária cuidadosamente controlada: reconhecer registros legados, verificar a senha antiga, gerar hash imediatamente após login válido e remover o caminho legado após prazo definido. Nunca publique um endpoint de migração que aceite um hash fornecido pelo cliente.

### Passo 7 — Testar hash e persistência

Depois de adicionar o pacote, testes unitários do serviço devem confirmar:

```dart
test('hash valida a senha original e não revela a senha', () async {
  const password = 'uma-senha-de-teste';
  final hash = await PasswordHasher.hashPassword(password);

  expect(hash, isNot(password));
  expect(
    await PasswordHasher.verifyPassword(
      password: password,
      storedHash: hash,
    ),
    isTrue,
  );
  expect(
    await PasswordHasher.verifyPassword(
      password: 'senha-incorreta',
      storedHash: hash,
    ),
    isFalse,
  );
});
```

Não comparar duas saídas BCrypt uma com a outra para esperar igualdade; cada chamada usa salt novo. Testes de handler/repos devem verificar que o valor armazenado é o hash, que login válido/incorreto retorna status correto e que a resposta nunca contém senha ou hash.

## Outros defeitos concretos

### Respostas Shelf com mapa como body

Shelf não serializa automaticamente um `Map` em JSON. Atualmente há respostas com `body: {'message': ...}`. Centralize:

```dart
Response _json(int status, Object body) => Response(
  status,
  body: jsonEncode(body),
  headers: {'content-type': 'application/json; charset=utf-8'},
);
```

Use `_json` em todas as respostas JSON, inclusive erros. Respostas 204 devem continuar sem body.

### Corrigir atualização em ambas as tabelas

A busca em `Usuarios` precisa usar `usuario_id`, não `id`. A coluna de chave no perfil é `id`, não `usuario_id`. Atualizar com uma única coluna de filtro em todas as tabelas falha. Faça a operação em transação e escolha a coluna conforme a tabela:

```dart
final idColumn = table == 'Usuarios' ? 'usuario_id' : 'id';
final changed = await txn.update(
  table,
  valuesWithoutId,
  where: '$idColumn = ?',
  whereArgs: [user.id],
);
```

Antes disso, confirme a existência por `Usuarios.usuario_id`. Se qualquer tabela de perfil necessária não for atualizada, lance exceção dentro da transação para reverter tudo. Não envie `senha: null` no mapa de update; mantenha o hash existente, alterando-o apenas num fluxo explícito de troca de senha.

## Testes desta revisão

`test/backend_contract_test.dart` foi ajustado às assinaturas atuais `Aluno.fromJson(id, json)` e `Professor.fromJson(id, json)`. Agora testa factories, geração/preservação do ID, conversão `toMap`/`fromMap` e revela explicitamente que a senha é `null` nos modelos criados sem senha/hash.

Não há testes HTTP nesta suíte porque `_buildHandler` e `_startApi` são privados, `iniciando()` fixa a porta 8080 e não devolve `HttpServer` para encerramento, e endpoints de banco acessam SQLite diretamente. A solução estrutural é injetar um repositório e expor um `Handler`/router construível para teste; até lá, alegar cobertura de cadastro/login seria enganoso.

## Padronizações aplicadas nesta revisão — aguardando sua autorização de manutenção

Conforme solicitado, apliquei no código de produção somente as padronizações de baixa prioridade abaixo. **Estão sem commit e ficam marcadas para sua revisão/autorização:**

- `loginApi` → `LoginApi`; arquivo `loginAPI.dart` → `login_api.dart`; import/construção no entrypoint atualizados.
- `fileControll` → `FileController`; arquivo `fileControllAPI.dart` → `file_controller_api.dart`.
- Parâmetro `id_json` → `idJson` nos factories de `Aluno` e `Professor`.

**Revisão do usuário:** [ ] autorizo manter essas padronizações  [ ] peço para revertê-las.

Não alterei a implementação de hash, os handlers ou o repositório: os defeitos funcionais estão detalhados acima para uma mudança corretiva separada.

## Validação executada

Antes de atualizar os testes, `flutter test` falhava porque os testes passavam um único argumento para `fromJson` e chamavam `startApi`, que não existe como método público na versão atual. O analyzer também reportava esses erros de teste.

Depois da atualização:

- `flutter test`: **6 testes passaram**.
- `flutter analyze`: **nenhum erro de compilação**, mas 25 diagnósticos (avisos/informações), incluindo o uso de `path.hash` com `await` e variáveis `user` sombreadas no cadastro.
- O teste atual é unitário dos modelos; não afirma validar o handler HTTP nem a persistência real.
- Hot restart foi tentado, mas não havia aplicativo conectado ao Dart Tooling Daemon.
