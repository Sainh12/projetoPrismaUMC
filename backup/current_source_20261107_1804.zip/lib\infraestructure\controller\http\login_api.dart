import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as passwordHasher;
import 'package:projeto_base_prisma/infraestructure/repository/gerenciadoBancoDeDados.dart';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:shelf_router/shelf_router.dart';

import 'package:projeto_base_prisma/domain/Aluno.dart';
import 'package:projeto_base_prisma/domain/User.dart';
import 'package:projeto_base_prisma/domain/Professor.dart';
import 'package:sqflite/sqflite.dart';

class LoginApi {
  final router = Router();
  final GerenciadorBancoDeDados gerenciador = GerenciadorBancoDeDados();

  Handler _buildHandler() {
    router.get("/api/test", _getTest);
    router.get("/api/users/info", _getUser);
    router.get("/api/users/id", _getId);
    router.post("/api/users/cadastrar", _postLogin);
    router.post("/api/users/acesso", _enterSystem);
    router.patch("/api/users/<id>", _atualizarUsuario);
    router.delete("/api/users/<id>", _deletarUsuario);
    //router.post("/api/users/professor", _postProfessor);
    //router.post("/api/users/aluno", _postAluno);

    return const Pipeline()
        .addMiddleware(logRequests())
        .addHandler(router.call);
  }

  Future<HttpServer> _startApi({InternetAddress? address, int port = 8080}) {
    return shelf_io.serve(
      _buildHandler(),
      address ?? InternetAddress.anyIPv4,
      port,
    );
  }

  Future<List<String>> iniciando() async {
    final server = await _startApi();
    final String serverAddress = server.address.host;
    final String serverPort = server.port.toString();
    return [serverAddress, serverPort];
  }

  //====================================================================
  Future<Response> _getUser(Request request) async {
    final String? emailRecebido = request.url.queryParameters['email'];
    if (emailRecebido == null || emailRecebido.trim().isEmpty) {
      return Response(400, body: '{"message":"email obrigatório"}');
    }
    final User? user = await gerenciador.getUserByEmail(emailRecebido);
    if (user == null) {
      return Response.notFound(
        jsonEncode({'message': 'Usuário não encontrado'}),
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    }
    final responseUser = {
      'id': user.id,
      'nome': user.nome,
      'email': user.email,
      'cpf': user.cpf,
      'escola': user.escola,
      'tipo_usuario': user.tipoUsuario,
      if (user is Aluno) 'serie': user.serie,
      if (user is Professor) ...{
        'materia': user.materia,
        'licenciatura': user.licenciatura,
      },
    };

    return Response.ok(
      jsonEncode(responseUser),
      headers: {'content-type': 'application/json; charset=utf-8'},
    );
  }

  //====================================================================
  Future<Response> _getId(Request request) async{
    final String? emailRecebido = request.url.queryParameters['email'];
    if (emailRecebido == null || emailRecebido.trim().isEmpty){
      return Response (400, body: '{message} : email nulo');
    }
    final User? user = await gerenciador.getUserByEmail(emailRecebido);
    if (user == null) {
      return Response.notFound(
        jsonEncode({'message': 'Usuário não encontrado'}),
        headers: {'content-type': 'application/json; charset=utf-8'},
    );
    }
    final responseUser = {'id': user.id};

    return Response.ok(
      jsonEncode(responseUser),
      headers: {'content-type': 'application/json; charset=utf-8'},
    );
  }


  //=================================================================
  Future<Response> _postLogin(Request request) async {
    //Lê o corpo da requisição
    final body = await request.readAsString();
    final Object? data;
    User? user;

    //Converter o JSON recebido em um mapa Dart
    try {
      data = jsonDecode(body);
    } on FormatException {
      return Response(
        400,
        body: '{"message":"JSON inválido"}',
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    }

    if (data is! Map<String, dynamic>) {
      return Response(
        400,
        body: '{"message":"Objeto JSON esperado"}',
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    }

    final tipo = data['tipo_usuario'];
    if (tipo != 'aluno' && tipo != 'professor') {
      return Response(
        400,
        body: {'message': 'tipo_usuario inválido'},
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    }
    final hash = await passwordHasher.hash(data['senha']);

    switch (tipo) {
      case 'professor':
        user = Professor.fromJson(null, data);
        break;
      case 'aluno':
        user = Aluno.fromJson(null, data);
        break;
    }

    try {
      final resposta = await gerenciador.insertUser(user!);
      if (resposta == 0) {
        return Response(
          409,
          body: {'message': 'Email ou CPF já cadastrado'},
          headers: {'content-type': 'application/json; charset=utf-8'},
        );
      }
      return Response(201, body: {'message': 'Usuário criado'},
          headers: {'content-type': 'application/json; charset=utf-8'},);
    } on DatabaseException catch (error, stackTrace) {
      return Response(
        409,
        body: {'message': 'Falha ao cadastrar'},
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    }
  }

  //========================================================================
  /* 
  COMO CHAMAR O MÉTODO NO FLUTTER

  final response = await http.post(
  Uri.parse('$baseUrl/api/users/acesso'),
  headers: {'content-type': 'application/json'},
  body: jsonEncode({'email': email, 'senha': senha}),);
  */
//-----------------------------------------------------------------
  String? _requiredString(Map<String, dynamic> data, String key) {
    final value = data[key];
    if (value is! String || value.trim().isEmpty) return null;
    return value.trim();
  }
//-----------------------------------------------------------------
  Future<Response> _enterSystem(Request request) async {
    //Formatando informações para trabalhar com elas
    final body = await request.readAsString();
    final Object? data;

    //Converter o JSON recebido em um mapa Dart
    try {
      data = jsonDecode(body);
    } on FormatException {
      return Response(400, body: '{"message":"JSON inválido"}',
          headers: {'content-type': 'application/json; charset=utf-8'},);
    }
    if (data is! Map<String, dynamic>) {
      return Response(400, body: '{"message":"Objeto JSON esperado"}',
          headers: {'content-type': 'application/json; charset=utf-8'},);
    }
    final email = _requiredString(data, 'email');
    final senha = _requiredString(data, 'senha');
    if (email == null || senha == null) {
      return Response(
        400,
        body: {'message': 'email e senha são obrigatórios'},
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    }

    final hash = await passwordHasher.hash(senha); 
 
    //Acesso ao Banco de dados
    final bool resposta = await gerenciador.getUserByEmailAndPassword(email,senha
    );

    if (resposta) {
      return Response.ok(
        jsonEncode({'message': 'Usuario encontrado com sucesso'}),
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    }
    return Response(
      401,
      body: jsonEncode({'message': 'Usuário não encontrado'}),
      headers: {'content-type': 'application/json; charset=utf-8'},
    );
  }
  //========================================================================
  /*Para usar o PATCH antes faça um GET para acessar os dados do user
  e ent vc salva esses dados em um objeto e usa eles para FAZER O PATCH
  O PATCH USA O ID DO USUARIO, que SÓ TEM NO BANCO*/

  Future<Response> _atualizarUsuario(Request request, String? id) async {
    final body = await request.readAsString();
    final Object? data;
    if (id == null) return Response.badRequest(body: 'Id inválido');

    //Converter o JSON recebido em um mapa Dart
    try {
      data = jsonDecode(body);
    } on FormatException {
      return Response(400, body: '{"message":"JSON inválido"}');
    }
    if (data is! Map<String, dynamic>) {
      return Response(400, body: '{"message":"Objeto JSON esperado"}');
    }
    int resposta = 0;

    if (data['tipo_usuario'] == 'professor') {
      final professor = Professor.fromJson(id, data);
      resposta = await gerenciador.atualizacaoUsuario(professor);
    } else if (data['tipo_usuario'] == 'aluno') {
      final aluno = Aluno.fromJson(id, data);
      resposta = await gerenciador.atualizacaoUsuario(aluno);
    }
    //Resposta para o flutter
    if (resposta == 0) {
      return Response(
        404,
        body: jsonEncode({'message': 'usuario não encontrado'}),
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    }
    return Response(204);
  }

  //========================================================================
  /*Para usar o DELETE antes faça um GET para acessar os dados do user
  e ent vc salva esses dados em um objeto e usa eles para FAZER O INSERT
  O DELETE USAR O ID DO USUARIO, que SÓ TEM NO BANCO*/

  Future<Response> _deletarUsuario(Request request, String? id) async {
    if (id == null) return Response.badRequest(body: 'Id inválido');
    final removidos = await gerenciador.deletarUser(id);
    if (removidos == 0) {
      return Response(
        404,
        body: jsonEncode({'message': 'usuario não encontrado'}),
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    }
    //Resposta para o flutter
    return Response(204);
  }

  //====================================================================
  Future<Response> _getTest(Request request) async {
    final users = [
      {
        'id': '1',
        'nome': 'Saimon',
        'email': 'saimon@hotmail.com',
        'escola': 'Escola A',
        'serie': '3° ano',
        'turma': 'A',
      },
      {
        'id': '2',
        'nome': 'João',
        'email': 'joaoxeroso@hotmail.com',
        'escola': 'Escola A',
        'serie': '3° ano',
        'turma': 'B',
      },
    ];
    return Response.ok(
      jsonEncode(users),
      headers: {'content-type': 'application/json; charset=utf-8'},
    );
  }
}
//========================================================================
/*Future<Response> _postProfessor(Request request) async {
  //Lê o corpo da requisição
  final body = await request.readAsString();

  //Converter o JSON recebido em um mapa Dart
  final data = jsonDecode(body) as Map<String, dynamic>;

  //Acessas os valores
  final String nome = data['nome'] as String;
  final String email = data['email'] as String;
  final String senha = data['senha'] as String;
  final String escola = data['escola'] as String;
  final String materia = data['materia'] as String;

  print('Recebido: nome=$nome, email=$email, escola=$escola, materia=$materia');

  //Resposta para o flutter

  return Response(
    201,
    body: jsonEncode({'message': 'Usuário recebido com sucesso'}),
    headers: {'content-type': 'application/json; charset=utf-8'},
  );
}

//==================================================================
Future<Response> _postAluno(Request request) async {
  //Lê o corpo da requisição
  final body = await request.readAsString();

  //Converter o JSON recebido em um mapa Dart
  final data = jsonDecode(body) as Map<String, dynamic>;

  //Acessas os valores
  final String nome = data['nome'] as String;
  final String email = data['email'] as String;
  final String senha = data['senha'] as String;
  final String escola = data['escola'] as String;
  final String serie = data['serie'] as String;
  final String turma = data['turma'] as String;

  print(
    'Recebido: nome=$nome, email=$email, escola=$escola, serie=$serie, turma=$turma',
  );

  //Resposta para o flutter

  return Response(
    201,
    body: jsonEncode({'message': 'Usuário recebido com sucesso'}),
    headers: {'content-type': 'application/json; charset=utf-8'},
  );
}*/
